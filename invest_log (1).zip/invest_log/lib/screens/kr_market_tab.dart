import 'package:flutter/material.dart';

import '../data/widget_catalog.dart';
import '../util/format.dart';
import '../util/naver.dart';
import '../widgets/web_card.dart';

const _kospiInfo = '코스피는 삼성전자처럼 한국을 대표하는 큰 기업들의 주가를 모은 지수예요.\n\n'
    '• 큰 숫자는 현재 지수, 아래는 어제보다 얼마나 변했는지예요.\n'
    '• 작은 그래프는 최근 약 3개월 흐름이에요.\n\n'
    '→ 지금 한국 시장이 오르는 추세인지, 쉬어가는 구간인지 볼 때 확인해요. '
    '오른쪽 위 확대 버튼을 누르면 네이버 증권에서 자세한 차트를 볼 수 있어요.';

const _kosdaqInfo = '코스닥은 IT·바이오처럼 성장성이 큰 중소·벤처 기업들의 지수예요.\n\n'
    '• 코스피보다 움직임(변동성)이 큰 편이에요.\n\n'
    '→ 중소형주·성장주 분위기를 파악할 때 확인해요.';

const _bigCapInfo = '코스피에서 규모가 큰 대표 기업들의 현재가와 하루 등락률이에요.\n\n'
    '• 빨강은 오름, 파랑은 내림이에요.\n'
    '• 종목을 누르면 네이버 증권에서 차트와 뉴스를 볼 수 있어요.\n\n'
    '→ 오늘 코스피를 움직이는 핵심 종목을 빠르게 볼 때 확인해요.';

const _bigCaps = [
  ['005930', '삼성전자'],
  ['000660', 'SK하이닉스'],
  ['373220', 'LG에너지솔루션'],
  ['207940', '삼성바이오로직스'],
  ['005380', '현대차'],
  ['000270', '기아'],
  ['068270', '셀트리온'],
  ['105560', 'KB금융'],
  ['035420', 'NAVER'],
  ['012450', '한화에어로스페이스'],
];

void _openPage(BuildContext context, String title, String info, String url) {
  Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => FullWebPage(
        item: MarketWidget(title: title, info: info, url: url)),
  ));
}

class KrMarketTab extends StatefulWidget {
  const KrMarketTab({super.key});

  @override
  State<KrMarketTab> createState() => _KrMarketTabState();
}

class _KrMarketTabState extends State<KrMarketTab>
    with AutomaticKeepAliveClientMixin {
  Quote? _kospi, _kosdaq;
  List<double> _kospiHist = [], _kosdaqHist = [];
  final Map<String, Quote?> _stocks = {};
  bool _loading = true;
  bool _failed = false;
  DateTime? _updated;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final results = await Future.wait([
      fetchIndexQuote('KOSPI'),
      fetchIndexQuote('KOSDAQ'),
      fetchIndexHistory('KOSPI'),
      fetchIndexHistory('KOSDAQ'),
      for (final s in _bigCaps) fetchStockQuote(s[0], s[1]),
    ]);
    if (!mounted) return;
    setState(() {
      _kospi = results[0] as Quote?;
      _kosdaq = results[1] as Quote?;
      _kospiHist = results[2] as List<double>;
      _kosdaqHist = results[3] as List<double>;
      for (int i = 0; i < _bigCaps.length; i++) {
        _stocks[_bigCaps[i][0]] = results[4 + i] as Quote?;
      }
      _failed = _kospi == null && _kosdaq == null;
      _loading = false;
      _updated = DateTime.now();
    });
  }

  String _time(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(top: 6, bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 8, 0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    _loading
                        ? '불러오는 중...'
                        : _failed
                            ? '시세를 불러오지 못했어요. 인터넷 연결을 확인하고 새로고침하세요.'
                            : '네이버 증권 기준 · ${_time(_updated!)} 업데이트 · 아래로 당기면 새로고침',
                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ),
                IconButton(
                  tooltip: '새로고침',
                  icon: const Icon(Icons.refresh),
                  onPressed: _loading ? null : _load,
                ),
              ],
            ),
          ),
          _IndexCard(
            title: '코스피',
            code: 'KOSPI',
            info: _kospiInfo,
            quote: _kospi,
            history: _kospiHist,
            loading: _loading,
          ),
          _IndexCard(
            title: '코스닥',
            code: 'KOSDAQ',
            info: _kosdaqInfo,
            quote: _kosdaq,
            history: _kosdaqHist,
            loading: _loading,
          ),
          _bigCapCard(context),
          for (final w in krWidgets) WebCard(item: w),
        ],
      ),
    );
  }

  Widget _bigCapCard(BuildContext context) {
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 4, 0),
            child: Row(
              children: [
                const Expanded(
                  child: Text('코스피 대형주',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                IconButton(
                  icon: const Icon(Icons.info_outline),
                  onPressed: () =>
                      showInfoSheet(context, '코스피 대형주', _bigCapInfo),
                ),
              ],
            ),
          ),
          for (final s in _bigCaps)
            _stockRow(context, s[0], s[1], _stocks[s[0]]),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _stockRow(BuildContext context, String code, String name, Quote? q) {
    final color = q == null ? Colors.grey : pnlColor(q.pct);
    return ListTile(
      dense: true,
      title: Text(name,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
      subtitle: Text(code),
      trailing: q == null
          ? Text(_loading ? '...' : '-',
              style: const TextStyle(color: Colors.grey))
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${fmtNum(q.price)}원',
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.bold)),
                Text(fmtPct(q.pct),
                    style: TextStyle(fontSize: 13, color: color)),
              ],
            ),
      onTap: () => _openPage(context, name, _bigCapInfo, naverStockPage(code)),
    );
  }
}

class _IndexCard extends StatelessWidget {
  final String title;
  final String code;
  final String info;
  final Quote? quote;
  final List<double> history;
  final bool loading;

  const _IndexCard({
    required this.title,
    required this.code,
    required this.info,
    required this.quote,
    required this.history,
    required this.loading,
  });

  @override
  Widget build(BuildContext context) {
    final q = quote;
    final color = q == null ? Colors.grey : pnlColor(q.change);
    final trendUp = history.length >= 2 && history.last >= history.first;
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 4, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(title,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                if (q?.marketStatus != null)
                  Text(q!.marketStatus == 'OPEN' ? '장중' : '장마감',
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black45)),
                IconButton(
                  tooltip: '설명',
                  icon: const Icon(Icons.info_outline),
                  onPressed: () => showInfoSheet(context, title, info),
                ),
                IconButton(
                  tooltip: '자세한 차트',
                  icon: const Icon(Icons.open_in_full),
                  onPressed: () =>
                      _openPage(context, title, info, naverIndexPage(code)),
                ),
              ],
            ),
            if (q == null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(loading ? '불러오는 중...' : '불러오지 못했어요',
                    style: const TextStyle(color: Colors.grey)),
              )
            else ...[
              Text(fmtNum(q.price, decimals: 2),
                  style: const TextStyle(
                      fontSize: 30, fontWeight: FontWeight.bold)),
              Text(
                  '${q.change > 0 ? '▲' : q.change < 0 ? '▼' : ''} '
                  '${fmtNum(q.change.abs(), decimals: 2)}  (${fmtPct(q.pct)})',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600, color: color)),
            ],
            if (history.length >= 2) ...[
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: SizedBox(
                  height: 110,
                  width: double.infinity,
                  child: CustomPaint(
                    painter: _Sparkline(history, pnlColor(trendUp ? 1 : -1)),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text('최근 ${history.length}거래일',
                  style: const TextStyle(fontSize: 12, color: Colors.black45)),
            ],
          ],
        ),
      ),
    );
  }
}

class _Sparkline extends CustomPainter {
  final List<double> values;
  final Color color;
  _Sparkline(this.values, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    var minV = values.first, maxV = values.first;
    for (final v in values) {
      if (v < minV) minV = v;
      if (v > maxV) maxV = v;
    }
    final range = (maxV - minV) == 0 ? 1 : (maxV - minV);
    final dx = size.width / (values.length - 1);
    final line = Path();
    for (int i = 0; i < values.length; i++) {
      final x = i * dx;
      final y = size.height - (values[i] - minV) / range * size.height;
      if (i == 0) {
        line.moveTo(x, y);
      } else {
        line.lineTo(x, y);
      }
    }
    final fill = Path.from(line)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(fill, Paint()..color = color.withAlpha(30));
    canvas.drawPath(
        line,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..isAntiAlias = true);
  }

  @override
  bool shouldRepaint(covariant _Sparkline old) =>
      old.values != values || old.color != color;
}
