import 'package:flutter/material.dart';

import '../data/widget_catalog.dart';
import '../widgets/web_card.dart';
import 'kr_market_tab.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  Widget _list(List<MarketWidget> items) => ListView.builder(
        padding: const EdgeInsets.only(top: 6, bottom: 24),
        itemCount: items.length,
        itemBuilder: (_, i) => WebCard(item: items[i]),
      );

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('시장 대시보드'),
          bottom: const TabBar(
            tabs: [
              Tab(text: '국내주식'),
              Tab(text: '미국주식'),
              Tab(text: '암호화폐'),
            ],
          ),
        ),
        body: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          children: [
            const KrMarketTab(),
            _list(usWidgets),
            _list(coinWidgets),
          ],
        ),
      ),
    );
  }
}
