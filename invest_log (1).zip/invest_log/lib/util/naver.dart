import 'dart:convert';
import 'dart:io';

/// 네이버 금융 공개 JSON(키 필요 없음)에서 국내 지수·종목 시세를 가져옵니다.
class Quote {
  final String name;
  final double price;
  final double change;
  final double pct;
  final String? marketStatus; // OPEN / CLOSE

  const Quote({
    required this.name,
    required this.price,
    required this.change,
    required this.pct,
    this.marketStatus,
  });
}

double _n(dynamic v) {
  if (v == null) return 0;
  if (v is num) return v.toDouble();
  return double.tryParse(
          v.toString().replaceAll(',', '').replaceAll('+', '').trim()) ??
      0;
}

Future<dynamic> _getJson(String url) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req = await client.getUrl(Uri.parse(url));
    req.headers.set(HttpHeaders.userAgentHeader,
        'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36');
    req.headers.set(HttpHeaders.refererHeader, 'https://m.stock.naver.com/');
    req.headers.set(HttpHeaders.acceptHeader, 'application/json');
    final res = await req.close().timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) return null;
    final body = await res.transform(utf8.decoder).join();
    return jsonDecode(body);
  } catch (_) {
    return null;
  } finally {
    client.close(force: true);
  }
}

Future<Quote?> _quote(String url, String fallbackName) async {
  final j = await _getJson(url);
  if (j is! Map) return null;
  final datas = j['datas'];
  if (datas is! List || datas.isEmpty) return null;
  final d = datas.first as Map;
  var change = _n(d['compareToPreviousClosePrice']);
  var pct = _n(d['fluctuationsRatio']);
  final dir = (d['compareToPreviousPrice'] is Map)
      ? (d['compareToPreviousPrice']['name'] ?? '').toString()
      : '';
  if (dir.contains('FALLING') || dir.contains('LOWER')) {
    change = -change.abs();
    pct = -pct.abs();
  }
  return Quote(
    name: (d['stockName'] ?? d['indexName'] ?? fallbackName).toString(),
    price: _n(d['closePrice']),
    change: change,
    pct: pct,
    marketStatus: d['marketStatus']?.toString(),
  );
}

/// code: KOSPI 또는 KOSDAQ
Future<Quote?> fetchIndexQuote(String code) => _quote(
    'https://polling.finance.naver.com/api/realtime/domestic/index/$code',
    code);

/// code: 6자리 종목코드 (예: 005930)
Future<Quote?> fetchStockQuote(String code, String name) => _quote(
    'https://polling.finance.naver.com/api/realtime/domestic/stock/$code',
    name);

/// 지수의 최근 일별 종가 (오래된 것 → 최신 순)
Future<List<double>> fetchIndexHistory(String code, {int days = 60}) async {
  final j = await _getJson(
      'https://m.stock.naver.com/api/index/$code/price?pageSize=$days&page=1');
  if (j is! List) return [];
  final list = <double>[];
  for (final e in j) {
    if (e is Map) {
      final v = _n(e['closePrice']);
      if (v > 0) list.add(v);
    }
  }
  return list.reversed.toList();
}

String naverIndexPage(String code) =>
    'https://m.stock.naver.com/domestic/index/$code/total';

String naverStockPage(String code) =>
    'https://m.stock.naver.com/domestic/stock/$code/total';
