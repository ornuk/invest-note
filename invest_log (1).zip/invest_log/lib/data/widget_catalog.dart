import 'dart:convert';

/// 대시보드에 들어가는 차트·지표 카드 정의
class MarketWidget {
  final String title;
  final String info; // ⓘ 버튼을 누르면 나오는 설명
  final String? url;
  final String? html;
  final double height;

  const MarketWidget({
    required this.title,
    required this.info,
    this.url,
    this.html,
    this.height = 360,
  });
}

String _embed(String type, Map<String, dynamic> cfg) {
  final hash = Uri.encodeComponent(jsonEncode(cfg));
  return 'https://s.tradingview.com/embed-widget/$type/?locale=kr#$hash';
}

String _chart(String symbol) => 'https://s.tradingview.com/widgetembed/'
    '?symbol=${Uri.encodeComponent(symbol)}'
    '&interval=D&hidesidetoolbar=1&symboledit=0&saveimage=0'
    '&toolbarbg=f1f3f6&theme=light&style=1'
    '&timezone=Asia%2FSeoul&locale=kr';

String _quote(String symbol) => _embed('single-quote', {
      'symbol': symbol,
      'colorTheme': 'light',
      'isTransparent': false,
      'width': '100%',
    });

String _overview(String title, List<List<String>> symbols) =>
    _embed('market-overview', {
      'colorTheme': 'light',
      'dateRange': '1M',
      'showChart': true,
      'isTransparent': false,
      'showSymbolLogo': true,
      'width': '100%',
      'height': '100%',
      'tabs': [
        {
          'title': title,
          'symbols': [
            for (final s in symbols) {'s': s[0], 'd': s[1]}
          ],
        }
      ],
    });

const _fxInfo = '원·달러 환율은 1달러를 사는 데 필요한 원화 금액이에요.\n\n'
    '• 숫자가 오르면 달러가 강해지고 원화가 약해진 거예요.\n'
    '• 숫자가 내리면 원화가 강해진 거예요.\n\n'
    '→ 환율이 오르면 미국 주식을 살 때 더 비싸지고, 외국인 자금이 빠져나가기 쉬워요. '
    '해외 투자나 외국인 매매 흐름을 볼 때 확인해요.';

const String _fearGreedHtml = r'''
<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{margin:0;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;background:#fff;color:#222}
.v{font-size:56px;font-weight:700;margin-top:-10px}.c{font-size:18px;margin-top:4px}.s{font-size:12px;color:#888;margin-top:8px}
</style></head><body>
<svg width="240" height="130" viewBox="0 0 240 130">
<defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stop-color="#1e88e5"/><stop offset=".5" stop-color="#bdbdbd"/><stop offset="1" stop-color="#e53935"/></linearGradient></defs>
<path d="M20 120 A100 100 0 0 1 220 120" fill="none" stroke="url(#g)" stroke-width="18" stroke-linecap="round"/>
<line id="n" x1="120" y1="120" x2="120" y2="35" stroke="#333" stroke-width="4" stroke-linecap="round"/>
<circle cx="120" cy="120" r="7" fill="#333"/></svg>
<div class="v" id="v">-</div><div class="c" id="c">불러오는 중...</div><div class="s" id="s"></div>
<script>
const ko={"Extreme Fear":"극단적 공포","Fear":"공포","Neutral":"중립","Greed":"탐욕","Extreme Greed":"극단적 탐욕"};
fetch("https://api.alternative.me/fng/?limit=1").then(r=>r.json()).then(j=>{
 const d=j.data[0];const v=parseInt(d.value);
 document.getElementById("v").textContent=v;
 document.getElementById("c").textContent=ko[d.value_classification]||d.value_classification;
 const t=new Date(parseInt(d.timestamp)*1000);
 document.getElementById("s").textContent="기준: "+t.toLocaleDateString("ko-KR");
 document.getElementById("n").setAttribute("transform","rotate("+(v*1.8-90)+" 120 120)");
}).catch(e=>{document.getElementById("c").textContent="불러오지 못했어요. 인터넷 연결을 확인하세요.";});
</script></body></html>
''';

/// 국내 탭은 네이버 시세로 직접 그리고(kr_market_tab.dart), 여기에는 환율만 둡니다.
/// TradingView 위젯은 한국거래소(KRX) 데이터를 보여주지 않아요.
final List<MarketWidget> krWidgets = [
  MarketWidget(
    title: '원·달러 환율',
    height: 150,
    url: _quote('FX_IDC:USDKRW'),
    info: _fxInfo,
  ),
];

final List<MarketWidget> usWidgets = [
  MarketWidget(
    title: 'S&P500 히트맵',
    height: 440,
    url: _embed('stock-heatmap', {
      'dataSource': 'SPX500',
      'blockSize': 'market_cap_basic',
      'blockColor': 'change',
      'grouping': 'sector',
      'colorTheme': 'light',
      'hasTopBar': false,
      'isDataSetEnabled': false,
      'isZoomEnabled': true,
      'hasSymbolTooltip': true,
      'isMonoSize': false,
      'width': '100%',
      'height': '100%',
    }),
    info: '히트맵은 시장 전체를 한눈에 보여주는 지도예요.\n\n'
        '• 칸 하나가 종목 하나예요.\n'
        '• 칸 크기 = 시가총액(회사 규모)\n'
        '• 초록 = 오름, 빨강 = 내림 (색이 진할수록 변동이 커요)\n\n'
        '→ 오늘 어느 업종·종목으로 돈이 몰리는지 볼 때 확인해요. '
        '자세히 보려면 오른쪽 위 확대 버튼을 누르세요.',
  ),
  MarketWidget(
    title: 'S&P500',
    height: 380,
    url: _chart('FOREXCOM:SPXUSD'),
    info: '미국에서 가장 큰 500개 회사를 모은 지수예요.\n\n'
        '→ 미국 주식시장 전체 방향을 확인할 때 봐요.',
  ),
  MarketWidget(
    title: '나스닥',
    height: 380,
    url: _chart('FOREXCOM:NSXUSD'),
    info: '애플, 엔비디아, 마이크로소프트 같은 기술 기업이 많이 모인 지수예요.\n\n'
        '→ 기술주·성장주 분위기를 알고 싶을 때 봐요.',
  ),
  MarketWidget(
    title: 'VIX 공포지수',
    height: 380,
    url: _chart('CAPITALCOM:VIX'),
    info: '투자자들이 얼마나 불안해하는지를 보여주는 지수예요.\n\n'
        '• 높을수록 불안, 낮을수록 안정이에요.\n'
        '• 보통 20 이상이면 시장이 긴장한 상태, 30 이상이면 크게 불안한 상태예요.\n\n'
        '→ 지금 시장이 불안한지 안정적인지 판단할 때 봐요.',
  ),
  MarketWidget(
    title: '원·달러 환율',
    height: 150,
    url: _quote('FX_IDC:USDKRW'),
    info: _fxInfo,
  ),
  MarketWidget(
    title: '미국 주요 종목',
    height: 460,
    url: _overview('주요 종목', [
      ['NASDAQ:NVDA', '엔비디아'],
      ['NASDAQ:AAPL', '애플'],
      ['NASDAQ:MSFT', '마이크로소프트'],
      ['NASDAQ:GOOG', '구글'],
      ['NASDAQ:TSLA', '테슬라'],
      ['NASDAQ:AVGO', '브로드컴'],
      ['NASDAQ:PLTR', '팔란티어'],
      ['NYSE:IONQ', '아이온큐'],
      ['NASDAQ:QQQ', 'QQQ'],
      ['AMEX:VOO', 'VOO'],
    ]),
    info: '많이 보는 미국 대표 종목과 ETF예요.\n\n'
        '• 종목을 누르면 위쪽 차트가 그 종목으로 바뀌어요.',
  ),
];

final List<MarketWidget> coinWidgets = [
  MarketWidget(
    title: '암호화폐 히트맵',
    height: 440,
    url: _embed('crypto-coins-heatmap', {
      'dataSource': 'Crypto',
      'blockSize': 'market_cap_calc',
      'blockColor': 'change',
      'colorTheme': 'light',
      'hasTopBar': false,
      'isDataSetEnabled': false,
      'isZoomEnabled': true,
      'hasSymbolTooltip': true,
      'width': '100%',
      'height': '100%',
    }),
    info: '코인 시장 전체를 한눈에 보여주는 지도예요.\n\n'
        '• 칸 크기 = 시가총액, 색 = 24시간 등락률\n'
        '• 초록은 오른 코인, 빨강은 내린 코인이에요.\n\n'
        '→ 오늘 코인 시장 분위기와 돈의 흐름을 볼 때 확인해요.',
  ),
  const MarketWidget(
    title: '공포탐욕지수',
    height: 260,
    html: _fearGreedHtml,
    info: '코인 투자자들의 심리를 0~100 숫자로 보여줘요.\n\n'
        '• 25 이하: 공포 (겁먹고 많이 판 상태)\n'
        '• 50 근처: 중립\n'
        '• 75 이상: 탐욕 (과열된 상태)\n\n'
        '→ 시장 분위기가 한쪽으로 지나치게 쏠렸는지 가볍게 체크할 때 봐요.',
  ),
  MarketWidget(
    title: '비트코인',
    height: 380,
    url: _chart('BITSTAMP:BTCUSD'),
    info: '가장 규모가 큰 암호화폐예요. 다른 코인들도 비트코인 방향을 많이 따라가요.\n\n'
        '→ 코인 시장이 상승 흐름인지 조정 중인지 먼저 판단할 때 봐요.',
  ),
  MarketWidget(
    title: '비트코인 도미넌스',
    height: 380,
    url: _chart('CRYPTOCAP:BTC.D'),
    info: '전체 코인 시장에서 비트코인이 차지하는 비율이에요.\n\n'
        '• 높아지면 → 비트코인 강세, 알트코인 약세\n'
        '• 낮아지면 → 알트코인 강세 (알트시즌)\n\n'
        '→ 돈이 비트코인에 몰리는지, 알트코인으로 퍼지는지 볼 때 확인해요.',
  ),
  MarketWidget(
    title: '이더리움',
    height: 380,
    url: _chart('BITSTAMP:ETHUSD'),
    info: '비트코인 다음으로 큰 암호화폐이자, 여러 서비스가 돌아가는 기반 네트워크예요.\n\n'
        '→ 알트코인 시장의 방향을 파악할 때 봐요.',
  ),
  MarketWidget(
    title: '주요 암호화폐',
    height: 460,
    url: _overview('주요 코인', [
      ['BITSTAMP:BTCUSD', '비트코인'],
      ['BITSTAMP:ETHUSD', '이더리움'],
      ['BINANCE:SOLUSDT', '솔라나'],
      ['BITSTAMP:XRPUSD', '리플'],
      ['BINANCE:BNBUSDT', 'BNB'],
      ['BINANCE:DOGEUSDT', '도지코인'],
    ]),
    info: '주요 코인의 현재 가격과 변동률이에요.\n\n'
        '→ 지금 어떤 코인이 강한지 빠르게 확인할 때 봐요.',
  ),
  MarketWidget(
    title: '원·달러 환율',
    height: 150,
    url: _quote('FX_IDC:USDKRW'),
    info: _fxInfo,
  ),
];
