﻿# 안드로이드 설정 보정: 인터넷 권한, 앱 이름
$ErrorActionPreference = 'Stop'
$p = Join-Path $PSScriptRoot 'android\app\src\main\AndroidManifest.xml'
$c = [IO.File]::ReadAllText($p)
if ($c -notmatch 'android.permission.INTERNET') {
  $c = $c -replace '(<manifest[^>]*>)', "`$1`r`n    <uses-permission android:name=`"android.permission.INTERNET`"/>"
}
$c = $c -replace 'android:label="[^"]*"', 'android:label="투자노트"'
$enc = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText($p, $c, $enc)
Write-Host '  AndroidManifest.xml 수정 완료'
