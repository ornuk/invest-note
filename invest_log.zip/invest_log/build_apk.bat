@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo   투자노트 APK 만들기
echo ==========================================
where flutter >nul 2>nul
if errorlevel 1 (
  echo [오류] flutter 명령을 찾을 수 없어요. Flutter가 설치되어 있는지 확인하세요.
  goto end
)
echo.
echo [1/4] 안드로이드 프로젝트 파일 만드는 중...
call flutter create --platforms=android --org com.investlog --project-name invest_log .
if errorlevel 1 goto fail
echo.
echo [2/4] 인터넷 권한, 앱 이름 설정 중...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0patch_android.ps1"
if errorlevel 1 goto fail
echo.
echo [3/4] 패키지 내려받는 중...
call flutter pub get
if errorlevel 1 goto fail
echo.
echo [4/4] APK 빌드 중... (처음에는 5~10분 걸릴 수 있어요)
call flutter build apk --release
if errorlevel 1 goto fail
copy /Y "build\app\outputs\flutter-apk\app-release.apk" "%~dp0InvestNote.apk" >nul
echo.
echo ==========================================
echo   완료! 이 폴더에 "InvestNote.apk" 파일이 생겼어요.
echo   폰으로 옮겨서 설치하세요.
echo ==========================================
start "" explorer /select,"%~dp0InvestNote.apk"
goto end
:fail
echo.
echo [오류] 빌드 중 문제가 생겼어요. 이 창의 빨간 글씨 부분을 캡처해서 Claude에게 보여주세요.
:end
echo.
pause
