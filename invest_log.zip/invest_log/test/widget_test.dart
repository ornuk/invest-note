import 'package:flutter_test/flutter_test.dart';
import 'package:invest_log/util/format.dart';

void main() {
  test('숫자 포맷', () {
    expect(fmtNum(1234567), '1,234,567');
    expect(fmtNum(-1500.5, decimals: 2), '-1,500.5');
  });
}
