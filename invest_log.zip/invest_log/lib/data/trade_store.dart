import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/trade.dart';

/// 매매 기록을 폰에만 저장하는 저장소 (shared_preferences에 JSON으로 저장)
class TradeStore extends ChangeNotifier {
  TradeStore._();
  static final TradeStore instance = TradeStore._();

  static const _key = 'trades_v1';
  final List<Trade> _trades = [];

  List<Trade> get all => List.unmodifiable(_trades);

  List<Trade> byStatus(TradeStatus s) {
    final list = _trades.where((t) => t.status == s).toList();
    list.sort((a, b) {
      final da = s == TradeStatus.holding ? a.buyDate : (a.sellDate ?? a.buyDate);
      final db = s == TradeStatus.holding ? b.buyDate : (b.sellDate ?? b.buyDate);
      return db.compareTo(da);
    });
    return list;
  }

  List<Trade> get closed =>
      _trades.where((t) => t.isClosed).toList();

  Trade? find(String id) {
    for (final t in _trades) {
      if (t.id == id) return t;
    }
    return null;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    _trades.clear();
    if (raw != null && raw.isNotEmpty) {
      try {
        final list = jsonDecode(raw) as List;
        for (final e in list) {
          _trades.add(Trade.fromJson(Map<String, dynamic>.from(e as Map)));
        }
      } catch (_) {
        // 손상된 데이터는 무시
      }
    }
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _key, jsonEncode(_trades.map((t) => t.toJson()).toList()));
    notifyListeners();
  }

  Future<void> add(Trade t) async {
    _trades.add(t);
    await _save();
  }

  Future<void> update(Trade t) async {
    final i = _trades.indexWhere((x) => x.id == t.id);
    if (i >= 0) {
      _trades[i] = t;
    } else {
      _trades.add(t);
    }
    await _save();
  }

  Future<void> delete(String id) async {
    _trades.removeWhere((t) => t.id == id);
    await _save();
  }

  /// 매도 처리. 수량이 보유 수량보다 적으면 부분 매도(새 기록으로 분리),
  /// 같거나 많으면 전체 매도. 익절/손절은 손익으로 자동 결정.
  Future<Trade> sell({
    required Trade trade,
    required double qty,
    required double price,
    required DateTime date,
    required double fxRate,
    required double fee,
    String sellReason = '',
  }) async {
    final original = find(trade.id) ?? trade;
    Trade sold;
    if (qty < original.qty) {
      sold = original.copy()
        ..id = Trade.newId()
        ..qty = qty
        ..fee = fee;
      original.qty = original.qty - qty;
      _trades.add(sold);
    } else {
      sold = original..fee = original.fee + fee;
    }
    sold
      ..sellPrice = price
      ..sellDate = date
      ..fxRate = sold.isKrw ? 1 : fxRate
      ..sellReason = sellReason.isNotEmpty ? sellReason : sold.sellReason;
    sold.status =
        (sold.pnl ?? 0) >= 0 ? TradeStatus.profit : TradeStatus.loss;
    await _save();
    return sold;
  }

  /// 매도를 취소하고 다시 보유로 돌리기
  Future<void> reopen(Trade t) async {
    t
      ..status = TradeStatus.holding
      ..sellPrice = null
      ..sellDate = null;
    await update(t);
  }

  String exportJson() =>
      jsonEncode(_trades.map((t) => t.toJson()).toList());

  /// 백업 가져오기. 성공하면 가져온 개수 반환, 실패하면 -1
  Future<int> importJson(String raw, {bool replace = true}) async {
    try {
      final list = jsonDecode(raw.trim()) as List;
      final parsed = list
          .map((e) => Trade.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      if (replace) _trades.clear();
      for (final t in parsed) {
        _trades.removeWhere((x) => x.id == t.id);
        _trades.add(t);
      }
      await _save();
      return parsed.length;
    } catch (_) {
      return -1;
    }
  }
}
