import 'package:flutter/material.dart';

enum Market { kr, us, coin }

extension MarketX on Market {
  String get label => const ['국내', '미국', '코인'][index];

  /// 노션 템플릿 규칙: 국내 빨강, 미국 초록, 코인 노랑
  Color get color => const [
        Color(0xFFE53935),
        Color(0xFF43A047),
        Color(0xFFF9A825),
      ][index];

  String get defaultCurrency => this == Market.kr ? 'KRW' : 'USD';
}

enum TradeStatus { holding, profit, loss }

extension TradeStatusX on TradeStatus {
  String get label => const ['보유', '익절', '손절'][index];
}

class Trade {
  String id;
  Market market;
  String name;
  String currency; // 'KRW' 또는 'USD'
  TradeStatus status;
  DateTime buyDate;
  double buyPrice;
  double qty;
  DateTime? sellDate;
  double? sellPrice;
  double fxRate; // USD일 때 1달러당 원화
  double fee; // 거래 통화 기준 수수료·세금
  String buyReason;
  String sellReason;
  String lesson;

  Trade({
    required this.id,
    required this.market,
    required this.name,
    required this.currency,
    required this.status,
    required this.buyDate,
    required this.buyPrice,
    required this.qty,
    this.sellDate,
    this.sellPrice,
    this.fxRate = 1,
    this.fee = 0,
    this.buyReason = '',
    this.sellReason = '',
    this.lesson = '',
  });

  static String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  bool get isKrw => currency == 'KRW';
  bool get isClosed => status != TradeStatus.holding && sellPrice != null;
  double get rate => isKrw ? 1 : (fxRate > 0 ? fxRate : 1);

  double get buyAmount => buyPrice * qty;
  double get buyAmountKrw => buyAmount * rate;

  double? get sellAmount => sellPrice == null ? null : sellPrice! * qty;

  double? get pnl =>
      sellPrice == null ? null : (sellPrice! - buyPrice) * qty - fee;
  double? get pnlKrw => pnl == null ? null : pnl! * rate;

  double? get returnPct {
    final p = pnl;
    if (p == null || buyAmount == 0) return null;
    return p / buyAmount * 100;
  }

  int? get holdingDays {
    final end = sellDate ?? DateTime.now();
    return end.difference(buyDate).inDays;
  }

  Trade copy() => Trade.fromJson(toJson());

  Map<String, dynamic> toJson() => {
        'id': id,
        'market': market.name,
        'name': name,
        'currency': currency,
        'status': status.name,
        'buyDate': buyDate.toIso8601String(),
        'buyPrice': buyPrice,
        'qty': qty,
        'sellDate': sellDate?.toIso8601String(),
        'sellPrice': sellPrice,
        'fxRate': fxRate,
        'fee': fee,
        'buyReason': buyReason,
        'sellReason': sellReason,
        'lesson': lesson,
      };

  static double _d(dynamic v, [double def = 0]) {
    if (v == null) return def;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString()) ?? def;
  }

  factory Trade.fromJson(Map<String, dynamic> j) => Trade(
        id: (j['id'] ?? newId()).toString(),
        market: Market.values.firstWhere((m) => m.name == j['market'],
            orElse: () => Market.kr),
        name: (j['name'] ?? '').toString(),
        currency: (j['currency'] ?? 'KRW').toString(),
        status: TradeStatus.values.firstWhere((s) => s.name == j['status'],
            orElse: () => TradeStatus.holding),
        buyDate: DateTime.tryParse((j['buyDate'] ?? '').toString()) ??
            DateTime.now(),
        buyPrice: _d(j['buyPrice']),
        qty: _d(j['qty']),
        sellDate: j['sellDate'] == null
            ? null
            : DateTime.tryParse(j['sellDate'].toString()),
        sellPrice: j['sellPrice'] == null ? null : _d(j['sellPrice']),
        fxRate: _d(j['fxRate'], 1),
        fee: _d(j['fee']),
        buyReason: (j['buyReason'] ?? '').toString(),
        sellReason: (j['sellReason'] ?? '').toString(),
        lesson: (j['lesson'] ?? '').toString(),
      );
}
