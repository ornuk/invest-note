import 'package:flutter/material.dart';

String _two(int n) => n.toString().padLeft(2, '0');

String fmtNum(double v, {int decimals = 0}) {
  final neg = v < 0;
  final s = v.abs().toStringAsFixed(decimals);
  final parts = s.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (int i = 0; i < intPart.length; i++) {
    if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(',');
    buf.write(intPart[i]);
  }
  var r = buf.toString();
  if (parts.length > 1) {
    final dec = parts[1].replaceFirst(RegExp(r'0+$'), '');
    if (dec.isNotEmpty) r += '.$dec';
  }
  return (neg ? '-' : '') + r;
}

String fmtKrw(double v) => '${fmtNum(v)}원';

String fmtSignedKrw(double v) => '${v > 0 ? '+' : ''}${fmtNum(v)}원';

String fmtPrice(double v, String currency) {
  if (currency == 'KRW') return '${fmtNum(v, decimals: v.abs() < 100 ? 2 : 0)}원';
  return '\$${fmtNum(v, decimals: v.abs() < 1 ? 6 : 2)}';
}

String fmtQty(double v) => fmtNum(v, decimals: 8);

String fmtPct(double v) => '${v > 0 ? '+' : ''}${v.toStringAsFixed(2)}%';

String fmtDate(DateTime d) => '${d.year}.${_two(d.month)}.${_two(d.day)}';

/// 한국식: 수익은 빨강, 손실은 파랑
Color pnlColor(double v) {
  if (v > 0) return const Color(0xFFE53935);
  if (v < 0) return const Color(0xFF1E88E5);
  return Colors.grey;
}

double? parseNum(String s) =>
    double.tryParse(s.replaceAll(',', '').replaceAll(' ', '').trim());
