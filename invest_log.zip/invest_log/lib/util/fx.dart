import 'dart:convert';
import 'dart:io';

/// 무료 환율 API(키 필요 없음)에서 1달러당 원화 환율을 가져옵니다.
Future<double?> fetchUsdKrw() async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req =
        await client.getUrl(Uri.parse('https://open.er-api.com/v6/latest/USD'));
    final res = await req.close().timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) return null;
    final body = await res.transform(utf8.decoder).join();
    final j = jsonDecode(body) as Map<String, dynamic>;
    final rates = j['rates'] as Map<String, dynamic>?;
    final krw = rates?['KRW'];
    if (krw is num) return krw.toDouble();
    return null;
  } catch (_) {
    return null;
  } finally {
    client.close(force: true);
  }
}
