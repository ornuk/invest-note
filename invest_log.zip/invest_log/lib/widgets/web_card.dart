import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../data/widget_catalog.dart';

WebViewController _makeController(MarketWidget w, VoidCallback onDone) {
  final c = WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..setBackgroundColor(Colors.white)
    ..setNavigationDelegate(NavigationDelegate(
      onPageFinished: (_) => onDone(),
      onWebResourceError: (_) => onDone(),
    ));
  if (w.html != null) {
    c.loadHtmlString(w.html!, baseUrl: 'https://localhost/');
  } else if (w.url != null) {
    c.loadRequest(Uri.parse(w.url!));
  }
  return c;
}

void showInfoSheet(BuildContext context, String title, String info) {
  showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 12),
            Text(info, style: const TextStyle(fontSize: 15, height: 1.5)),
          ],
        ),
      ),
    ),
  );
}

class WebCard extends StatefulWidget {
  final MarketWidget item;
  const WebCard({super.key, required this.item});

  @override
  State<WebCard> createState() => _WebCardState();
}

class _WebCardState extends State<WebCard> with AutomaticKeepAliveClientMixin {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _controller = _makeController(widget.item, () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  bool get wantKeepAlive => true;

  void _reload() {
    setState(() => _loading = true);
    if (widget.item.html != null) {
      _controller.loadHtmlString(widget.item.html!,
          baseUrl: 'https://localhost/');
    } else {
      _controller.reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final w = widget.item;
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 4, 0),
            child: Row(
              children: [
                Expanded(
                  child: Text(w.title,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                IconButton(
                  tooltip: '설명',
                  icon: const Icon(Icons.info_outline),
                  onPressed: () => showInfoSheet(context, w.title, w.info),
                ),
                IconButton(
                  tooltip: '새로고침',
                  icon: const Icon(Icons.refresh),
                  onPressed: _reload,
                ),
                IconButton(
                  tooltip: '크게 보기',
                  icon: const Icon(Icons.open_in_full),
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => FullWebPage(item: w)),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: w.height,
            child: Stack(
              children: [
                WebViewWidget(controller: _controller),
                if (_loading)
                  const Center(child: CircularProgressIndicator()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 차트를 화면 전체로 크게 보기 (확대·이동 가능)
class FullWebPage extends StatefulWidget {
  final MarketWidget item;
  const FullWebPage({super.key, required this.item});

  @override
  State<FullWebPage> createState() => _FullWebPageState();
}

class _FullWebPageState extends State<FullWebPage> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _controller = _makeController(widget.item, () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.item;
    return Scaffold(
      appBar: AppBar(
        title: Text(w.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () => showInfoSheet(context, w.title, w.info),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_loading) const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
