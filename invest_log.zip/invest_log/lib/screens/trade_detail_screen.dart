import 'package:flutter/material.dart';

import '../data/trade_store.dart';
import '../models/trade.dart';
import '../util/format.dart';
import '../util/fx.dart';
import 'trade_form_screen.dart';

class TradeDetailScreen extends StatefulWidget {
  final String tradeId;
  const TradeDetailScreen({super.key, required this.tradeId});

  @override
  State<TradeDetailScreen> createState() => _TradeDetailScreenState();
}

class _TradeDetailScreenState extends State<TradeDetailScreen> {
  final store = TradeStore.instance;
  final _buyReason = TextEditingController();
  final _sellReason = TextEditingController();
  final _lesson = TextEditingController();
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    final t = store.find(widget.tradeId);
    if (t != null) {
      _buyReason.text = t.buyReason;
      _sellReason.text = t.sellReason;
      _lesson.text = t.lesson;
    }
  }

  @override
  void dispose() {
    _buyReason.dispose();
    _sellReason.dispose();
    _lesson.dispose();
    super.dispose();
  }

  Future<void> _saveNote(Trade t) async {
    final c = t.copy()
      ..buyReason = _buyReason.text.trim()
      ..sellReason = _sellReason.text.trim()
      ..lesson = _lesson.text.trim();
    await store.update(c);
    if (!mounted) return;
    setState(() => _dirty = false);
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('복기 노트를 저장했어요.')));
  }

  Future<void> _delete(Trade t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('기록 삭제'),
        content: Text('"${t.name}" 기록을 삭제할까요?\n삭제하면 되돌릴 수 없어요.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('삭제')),
        ],
      ),
    );
    if (ok == true) {
      await store.delete(t.id);
      if (mounted) Navigator.of(context).pop();
    }
  }

  Future<void> _reopen(Trade t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('매도 취소'),
        content: const Text('매도 정보를 지우고 다시 "보유"로 돌릴까요?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('아니요')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('보유로 돌리기')),
        ],
      ),
    );
    if (ok == true) await store.reopen(t.copy());
  }

  Future<void> _sell(Trade t) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _SellSheet(trade: t),
    );
    final nt = store.find(widget.tradeId);
    if (nt != null && mounted) {
      setState(() => _sellReason.text = nt.sellReason);
    }
  }

  Widget _row(String label, String value, {Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            SizedBox(
                width: 110,
                child: Text(label,
                    style: const TextStyle(color: Colors.black54))),
            Expanded(
              child: Text(value,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                      fontWeight: FontWeight.w600, color: color, fontSize: 15)),
            ),
          ],
        ),
      );

  Widget _note(String label, String hint, TextEditingController c) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          maxLines: null,
          minLines: 2,
          onChanged: (_) {
            if (!_dirty) setState(() => _dirty = true);
          },
          decoration: InputDecoration(
              labelText: label, hintText: hint, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final t = store.find(widget.tradeId);
        if (t == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const Center(child: Text('기록을 찾을 수 없어요.')));
        }
        final pnl = t.pnlKrw;
        final pct = t.returnPct;
        return Scaffold(
          appBar: AppBar(
            title: Text(t.name),
            actions: [
              IconButton(
                tooltip: '수정',
                icon: const Icon(Icons.edit),
                onPressed: () async {
                  await Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => TradeFormScreen(editing: t)));
                  final nt = store.find(widget.tradeId);
                  if (nt != null && mounted) {
                    setState(() {
                      _buyReason.text = nt.buyReason;
                      _sellReason.text = nt.sellReason;
                      _lesson.text = nt.lesson;
                      _dirty = false;
                    });
                  }
                },
              ),
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'delete') _delete(t);
                  if (v == 'reopen') _reopen(t);
                },
                itemBuilder: (_) => [
                  if (t.isClosed)
                    const PopupMenuItem(
                        value: 'reopen', child: Text('매도 취소(보유로 돌리기)')),
                  const PopupMenuItem(value: 'delete', child: Text('삭제')),
                ],
              ),
            ],
          ),
          bottomNavigationBar: t.status == TradeStatus.holding
              ? SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: SizedBox(
                     width: double.infinity,
                     child: FilledButton.icon(
                      onPressed: () => _sell(t),
                      icon: const Icon(Icons.sell),
                      label: const Text('매도하기 (전체 또는 일부)'),
                      style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16)),
                    ),
                    ),
                  ),
                )
              : null,
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  Chip(
                    label: Text(t.market.label,
                        style: const TextStyle(color: Colors.white)),
                    backgroundColor: t.market.color,
                  ),
                  const SizedBox(width: 8),
                  Chip(label: Text(t.status.label)),
                ],
              ),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _row('매수일', fmtDate(t.buyDate)),
                      _row('매수 단가', fmtPrice(t.buyPrice, t.currency)),
                      _row('수량', fmtQty(t.qty)),
                      _row('매수 금액', fmtPrice(t.buyAmount, t.currency)),
                      if (!t.isKrw) ...[
                        _row('환율', '${fmtNum(t.fxRate, decimals: 2)}원'),
                        _row('원화 환산', fmtKrw(t.buyAmountKrw)),
                      ],
                      if (t.fee != 0)
                        _row('수수료·세금', fmtPrice(t.fee, t.currency)),
                      if (t.isClosed) ...[
                        const Divider(height: 24),
                        _row('매도일', fmtDate(t.sellDate!)),
                        _row('매도 단가', fmtPrice(t.sellPrice!, t.currency)),
                        _row('매도 금액', fmtPrice(t.sellAmount!, t.currency)),
                        if (pnl != null)
                          _row('손익(원화)', fmtSignedKrw(pnl),
                              color: pnlColor(pnl)),
                        if (pct != null)
                          _row('수익률', fmtPct(pct), color: pnlColor(pct)),
                      ],
                      _row('보유 기간', '${t.holdingDays ?? 0}일'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text('복기 노트', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              _note('매수 이유', '왜 샀나요? 어떤 근거였나요?', _buyReason),
              _note('매도 이유', '왜 팔았나요? 계획대로였나요?', _sellReason),
              _note('배운 점', '다음에 똑같은 상황이면 어떻게 할까요?', _lesson),
              FilledButton.tonal(
                onPressed: _dirty ? () => _saveNote(t) : null,
                child: const Text('복기 노트 저장'),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}

class _SellSheet extends StatefulWidget {
  final Trade trade;
  const _SellSheet({required this.trade});

  @override
  State<_SellSheet> createState() => _SellSheetState();
}

class _SellSheetState extends State<_SellSheet> {
  final _qty = TextEditingController();
  final _price = TextEditingController();
  final _fx = TextEditingController();
  final _fee = TextEditingController();
  final _reason = TextEditingController();
  DateTime _date = DateTime.now();
  String? _error;

  Trade get t => widget.trade;

  @override
  void initState() {
    super.initState();
    _qty.text = fmtNum(t.qty, decimals: 8);
    if (!t.isKrw) {
      _fx.text = fmtNum(t.fxRate, decimals: 2);
      fetchUsdKrw().then((r) {
        if (r != null && mounted) {
          setState(() => _fx.text = fmtNum(r, decimals: 2));
        }
      });
    }
  }

  @override
  void dispose() {
    for (final c in [_qty, _price, _fx, _fee, _reason]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    final qty = parseNum(_qty.text);
    final price = parseNum(_price.text);
    final fx = t.isKrw ? 1.0 : parseNum(_fx.text);
    if (qty == null || qty <= 0 || qty > t.qty + 1e-9) {
      setState(() => _error = '매도 수량은 0보다 크고 보유 수량(${fmtQty(t.qty)}) 이하여야 해요.');
      return;
    }
    if (price == null || price <= 0) {
      setState(() => _error = '매도 단가를 입력하세요.');
      return;
    }
    if (fx == null || fx <= 0) {
      setState(() => _error = '환율을 입력하세요.');
      return;
    }
    final sold = await TradeStore.instance.sell(
      trade: t,
      qty: qty >= t.qty - 1e-9 ? t.qty : qty,
      price: price,
      date: _date,
      fxRate: fx,
      fee: parseNum(_fee.text) ?? 0,
      sellReason: _reason.text.trim(),
    );
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).pop();
    final pnl = sold.pnlKrw ?? 0;
    messenger.showSnackBar(SnackBar(
        content: Text(
            '${sold.status.label} 처리했어요 (${fmtSignedKrw(pnl)}). ${sold.status.label} 탭에서 볼 수 있어요.')));
  }

  @override
  Widget build(BuildContext context) {
    final unit = t.isKrw ? '원' : '달러';
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${t.name} 매도',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text('보유 ${fmtQty(t.qty)} · 평단 ${fmtPrice(t.buyPrice, t.currency)}\n'
                '일부만 팔면 판 만큼 따로 기록되고, 남은 수량은 보유에 남아요.',
                style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event),
              title: const Text('매도일'),
              trailing: Text(fmtDate(_date), style: const TextStyle(fontSize: 16)),
              onTap: () async {
                final d = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: t.buyDate.subtract(const Duration(days: 1)),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                );
                if (d != null) setState(() => _date = d);
              },
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _qty,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                        labelText: '매도 수량', border: OutlineInputBorder()),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _price,
                    autofocus: true,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                        labelText: '매도 단가($unit)',
                        border: const OutlineInputBorder()),
                  ),
                ),
              ],
            ),
            if (!t.isKrw) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _fx,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                    labelText: '환율 (1달러 = ?원)', border: OutlineInputBorder()),
              ),
            ],
            const SizedBox(height: 12),
            TextField(
              controller: _fee,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                  labelText: '수수료·세금($unit, 선택)',
                  border: const OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _reason,
              maxLines: 2,
              decoration: const InputDecoration(
                  labelText: '매도 이유 (선택)', border: OutlineInputBorder()),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _submit,
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16)),
              child: const Text('매도 저장'),
            ),
          ],
        ),
      ),
    );
  }
}
