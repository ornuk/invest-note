import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/trade_store.dart';
import '../models/trade.dart';
import '../util/format.dart';
import 'trade_detail_screen.dart';
import 'trade_form_screen.dart';

class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  final store = TradeStore.instance;
  Market? _filter; // null = 전체

  Future<void> _export() async {
    await Clipboard.setData(ClipboardData(text: store.exportJson()));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('백업 내용을 복사했어요. 카톡 나에게 보내기나 메모에 붙여넣어 보관하세요.'),
    ));
  }

  Future<void> _import() async {
    final ctrl = TextEditingController();
    final clip = await Clipboard.getData(Clipboard.kTextPlain);
    if (clip?.text != null && clip!.text!.trim().startsWith('[')) {
      ctrl.text = clip.text!;
    }
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('백업 가져오기'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('복사해 둔 백업 내용을 붙여넣으세요.\n지금 기록은 백업 내용으로 바뀌어요.'),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              maxLines: 5,
              decoration: const InputDecoration(
                  border: OutlineInputBorder(), hintText: '[{...}]'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('취소')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('가져오기')),
        ],
      ),
    );
    if (ok != true) return;
    final n = await store.importJson(ctrl.text);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(n < 0 ? '백업 형식이 올바르지 않아요.' : '$n건을 가져왔어요.'),
    ));
  }

  List<Trade> _filtered(TradeStatus s) {
    final list = store.byStatus(s);
    if (_filter == null) return list;
    return list.where((t) => t.market == _filter).toList();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final holding = _filtered(TradeStatus.holding);
        final profit = _filtered(TradeStatus.profit);
        final loss = _filtered(TradeStatus.loss);
        return DefaultTabController(
          length: 3,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('매매일지'),
              actions: [
                PopupMenuButton<String>(
                  onSelected: (v) => v == 'export' ? _export() : _import(),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'export', child: Text('백업 내보내기(복사)')),
                    PopupMenuItem(value: 'import', child: Text('백업 가져오기')),
                  ],
                ),
              ],
              bottom: TabBar(tabs: [
                Tab(text: '보유 ${holding.length}'),
                Tab(text: '익절 ${profit.length}'),
                Tab(text: '손절 ${loss.length}'),
              ]),
            ),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const TradeFormScreen())),
              icon: const Icon(Icons.add),
              label: const Text('매수 기록'),
            ),
            body: Column(
              children: [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                  child: Row(
                    children: [
                      _chip('전체', null),
                      for (final m in Market.values) _chip(m.label, m),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(children: [
                    _holdingTab(holding),
                    _closedTab(profit, '익절한 기록이 없어요.'),
                    _closedTab(loss, '손절한 기록이 없어요.'),
                  ]),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _chip(String label, Market? m) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _filter == m,
          onSelected: (_) => setState(() => _filter = m),
        ),
      );

  Widget _empty(String msg) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(msg,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey, fontSize: 15)),
        ),
      );

  Widget _holdingTab(List<Trade> list) {
    if (list.isEmpty) {
      return _empty('보유 중인 종목이 없어요.\n아래 "매수 기록" 버튼으로 추가하세요.');
    }
    final total = list.fold<double>(0, (s, t) => s + t.buyAmountKrw);
    return ListView(
      padding: const EdgeInsets.only(bottom: 96),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text('총 매수금액(원화 환산) ${fmtKrw(total)}',
              style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
        for (final t in list) _TradeTile(trade: t),
      ],
    );
  }

  Widget _closedTab(List<Trade> list, String emptyMsg) {
    if (list.isEmpty) return _empty(emptyMsg);
    final total = list.fold<double>(0, (s, t) => s + (t.pnlKrw ?? 0));
    return ListView(
      padding: const EdgeInsets.only(bottom: 96),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text('합계 손익 ${fmtSignedKrw(total)}',
              style: TextStyle(
                  fontWeight: FontWeight.w600, color: pnlColor(total))),
        ),
        for (final t in list) _TradeTile(trade: t),
      ],
    );
  }
}

class _TradeTile extends StatelessWidget {
  final Trade trade;
  const _TradeTile({required this.trade});

  @override
  Widget build(BuildContext context) {
    final t = trade;
    final pnl = t.pnlKrw;
    final pct = t.returnPct;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => TradeDetailScreen(tradeId: t.id))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 6,
                height: 44,
                decoration: BoxDecoration(
                  color: t.market.color,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t.name,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: t.market.color)),
                    const SizedBox(height: 4),
                    Text(
                      t.isClosed
                          ? '${fmtDate(t.buyDate)} → ${fmtDate(t.sellDate!)} · ${fmtQty(t.qty)}주'
                          : '${fmtDate(t.buyDate)} 매수 · ${fmtQty(t.qty)}주 · 평단 ${fmtPrice(t.buyPrice, t.currency)}',
                      style: const TextStyle(fontSize: 13, color: Colors.black54),
                    ),
                  ],
                ),
              ),
              if (pnl != null && pct != null)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(fmtSignedKrw(pnl),
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: pnlColor(pnl))),
                    Text(fmtPct(pct),
                        style: TextStyle(fontSize: 13, color: pnlColor(pnl))),
                  ],
                )
              else
                Text(fmtKrw(t.buyAmountKrw),
                    style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}
