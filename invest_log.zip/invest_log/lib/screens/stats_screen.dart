import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/trade_store.dart';
import '../models/trade.dart';
import '../util/format.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = TradeStore.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('수익 통계')),
      body: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final closed = store.closed;
          if (closed.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text('아직 매도한 기록이 없어요.\n매도를 기록하면 여기에서 수익 통계를 볼 수 있어요.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey, fontSize: 15)),
              ),
            );
          }
          return _StatsBody(closed: closed);
        },
      ),
    );
  }
}

class _StatsBody extends StatelessWidget {
  final List<Trade> closed;
  const _StatsBody({required this.closed});

  @override
  Widget build(BuildContext context) {
    final total = closed.fold<double>(0, (s, t) => s + (t.pnlKrw ?? 0));
    final wins = closed.where((t) => (t.pnlKrw ?? 0) >= 0).toList();
    final losses = closed.where((t) => (t.pnlKrw ?? 0) < 0).toList();
    final winRate = wins.length / closed.length * 100;
    final avgPct = closed.fold<double>(0, (s, t) => s + (t.returnPct ?? 0)) /
        closed.length;
    final avgWin = wins.isEmpty
        ? 0.0
        : wins.fold<double>(0, (s, t) => s + t.pnlKrw!) / wins.length;
    final avgLoss = losses.isEmpty
        ? 0.0
        : losses.fold<double>(0, (s, t) => s + t.pnlKrw!) / losses.length;
    final avgDays =
        closed.fold<int>(0, (s, t) => s + (t.holdingDays ?? 0)) / closed.length;

    // 시장별
    final byMarket = <Market, double>{};
    for (final t in closed) {
      byMarket[t.market] = (byMarket[t.market] ?? 0) + (t.pnlKrw ?? 0);
    }

    // 최근 6개월
    final now = DateTime.now();
    final months = <DateTime>[
      for (int i = 5; i >= 0; i--) DateTime(now.year, now.month - i, 1)
    ];
    final monthly = <double>[
      for (final m in months)
        closed
            .where((t) =>
                t.sellDate != null &&
                t.sellDate!.year == m.year &&
                t.sellDate!.month == m.month)
            .fold<double>(0, (s, t) => s + (t.pnlKrw ?? 0))
    ];

    // 종목별
    final byName = <String, double>{};
    for (final t in closed) {
      byName[t.name] = (byName[t.name] ?? 0) + (t.pnlKrw ?? 0);
    }
    final ranked = byName.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text('실현 손익 합계',
                    style: TextStyle(color: Colors.black54)),
                const SizedBox(height: 6),
                Text(fmtSignedKrw(total),
                    style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: pnlColor(total))),
                const SizedBox(height: 4),
                Text('매도 ${closed.length}건 기준',
                    style: const TextStyle(color: Colors.black45)),
              ],
            ),
          ),
        ),
        Row(
          children: [
            _stat('승률', '${winRate.toStringAsFixed(1)}%',
                '${wins.length}승 ${losses.length}패'),
            _stat('평균 수익률', fmtPct(avgPct), null, color: pnlColor(avgPct)),
          ],
        ),
        Row(
          children: [
            _stat('평균 익절', fmtSignedKrw(avgWin), null,
                color: pnlColor(avgWin)),
            _stat('평균 손절', fmtSignedKrw(avgLoss), null,
                color: pnlColor(avgLoss)),
          ],
        ),
        Row(
          children: [
            _stat('평균 보유 기간', '${avgDays.toStringAsFixed(0)}일', null),
            _stat(
                '손익비',
                avgLoss == 0
                    ? '-'
                    : (avgWin / avgLoss.abs()).toStringAsFixed(2),
                '평균 익절 ÷ 평균 손절'),
          ],
        ),
        const SizedBox(height: 8),
        _section('월별 실현 손익 (최근 6개월)'),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
            child: _MonthlyBars(months: months, values: monthly),
          ),
        ),
        const SizedBox(height: 8),
        _section('시장별 손익'),
        Card(
          child: Column(
            children: [
              for (final m in Market.values)
                if (byMarket.containsKey(m))
                  ListTile(
                    leading: CircleAvatar(
                        backgroundColor: m.color,
                        radius: 8),
                    title: Text(m.label),
                    trailing: Text(fmtSignedKrw(byMarket[m]!),
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: pnlColor(byMarket[m]!))),
                  ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _section('종목별 손익'),
        Card(
          child: Column(
            children: [
              for (final e in ranked)
                ListTile(
                  dense: true,
                  title: Text(e.key),
                  trailing: Text(fmtSignedKrw(e.value),
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: pnlColor(e.value))),
                ),
            ],
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 12, 8, 6),
        child: Text(t,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      );

  Widget _stat(String label, String value, String? sub, {Color? color}) =>
      Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(color: Colors.black54)),
                const SizedBox(height: 6),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(value,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: color)),
                ),
                if (sub != null)
                  Text(sub,
                      style:
                          const TextStyle(fontSize: 12, color: Colors.black45)),
              ],
            ),
          ),
        ),
      );
}

class _MonthlyBars extends StatelessWidget {
  final List<DateTime> months;
  final List<double> values;
  const _MonthlyBars({required this.months, required this.values});

  String _short(double v) {
    final a = v.abs();
    String s;
    if (a >= 100000000) {
      s = '${(a / 100000000).toStringAsFixed(1)}억';
    } else if (a >= 10000) {
      s = '${(a / 10000).toStringAsFixed(a >= 1000000 ? 0 : 1)}만';
    } else {
      s = a.toStringAsFixed(0);
    }
    if (v > 0) return '+$s';
    if (v < 0) return '-$s';
    return '0';
  }

  @override
  Widget build(BuildContext context) {
    final maxAbs = values.fold<double>(0, (m, v) => math.max(m, v.abs()));
    const half = 70.0;
    return Column(
      children: [
        SizedBox(
          height: half * 2 + 32,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (int i = 0; i < values.length; i++)
                Expanded(
                  child: Column(
                    children: [
                      SizedBox(
                        height: 16,
                        child: values[i] > 0
                            ? FittedBox(
                                child: Text(_short(values[i]),
                                    style: TextStyle(
                                        color: pnlColor(values[i]))))
                            : null,
                      ),
                      SizedBox(
                        height: half,
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            width: 22,
                            height: maxAbs == 0 || values[i] <= 0
                                ? 0
                                : half * values[i] / maxAbs,
                            color: pnlColor(1),
                          ),
                        ),
                      ),
                      Container(height: 1, color: Colors.black26),
                      SizedBox(
                        height: half - 1,
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            width: 22,
                            height: maxAbs == 0 || values[i] >= 0
                                ? 0
                                : (half - 1) * values[i].abs() / maxAbs,
                            color: pnlColor(-1),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 16,
                        child: values[i] < 0
                            ? FittedBox(
                                child: Text(_short(values[i]),
                                    style: TextStyle(
                                        color: pnlColor(values[i]))))
                            : null,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            for (final m in months)
              Expanded(
                child: Text('${m.month}월',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12, color: Colors.black54)),
              ),
          ],
        ),
      ],
    );
  }
}
