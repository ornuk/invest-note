import 'package:flutter/material.dart';

import '../data/trade_store.dart';
import '../models/trade.dart';
import '../util/format.dart';
import '../util/fx.dart';

/// 매수 기록 추가 / 수정 화면
class TradeFormScreen extends StatefulWidget {
  final Trade? editing;
  const TradeFormScreen({super.key, this.editing});

  @override
  State<TradeFormScreen> createState() => _TradeFormScreenState();
}

class _TradeFormScreenState extends State<TradeFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late Market _market;
  late String _currency;
  late DateTime _buyDate;
  DateTime? _sellDate;
  final _name = TextEditingController();
  final _buyPrice = TextEditingController();
  final _qty = TextEditingController();
  final _fx = TextEditingController();
  final _fee = TextEditingController();
  final _sellPrice = TextEditingController();
  final _reason = TextEditingController();
  bool _fxLoading = false;

  bool get _isEdit => widget.editing != null;
  bool get _isClosed => widget.editing?.isClosed ?? false;

  @override
  void initState() {
    super.initState();
    final e = widget.editing;
    _market = e?.market ?? Market.kr;
    _currency = e?.currency ?? _market.defaultCurrency;
    _buyDate = e?.buyDate ?? DateTime.now();
    _sellDate = e?.sellDate;
    if (e != null) {
      _name.text = e.name;
      _buyPrice.text = fmtNum(e.buyPrice, decimals: 8);
      _qty.text = fmtNum(e.qty, decimals: 8);
      _fx.text = e.isKrw ? '' : fmtNum(e.fxRate, decimals: 2);
      _fee.text = e.fee == 0 ? '' : fmtNum(e.fee, decimals: 4);
      _reason.text = e.buyReason;
      if (e.sellPrice != null) {
        _sellPrice.text = fmtNum(e.sellPrice!, decimals: 8);
      }
    } else if (_currency == 'USD') {
      _loadFx();
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _buyPrice, _qty, _fx, _fee, _sellPrice, _reason]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadFx() async {
    setState(() => _fxLoading = true);
    final r = await fetchUsdKrw();
    if (!mounted) return;
    setState(() {
      _fxLoading = false;
      if (r != null) _fx.text = fmtNum(r, decimals: 2);
    });
    if (r == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('환율을 불러오지 못했어요. 직접 입력해 주세요.')));
    }
  }

  Future<void> _pickDate(bool sell) async {
    final init = sell ? (_sellDate ?? DateTime.now()) : _buyDate;
    final d = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d == null) return;
    setState(() {
      if (sell) {
        _sellDate = d;
      } else {
        _buyDate = d;
      }
    });
  }

  String? _required(String? v) {
    final n = parseNum(v ?? '');
    if (n == null || n <= 0) return '0보다 큰 숫자를 입력하세요';
    return null;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final isUsd = _currency == 'USD';
    final fx = isUsd ? (parseNum(_fx.text) ?? 0) : 1.0;
    if (isUsd && fx <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('환율을 입력하세요.')));
      return;
    }
    final store = TradeStore.instance;
    final t = widget.editing?.copy() ??
        Trade(
          id: Trade.newId(),
          market: _market,
          name: '',
          currency: _currency,
          status: TradeStatus.holding,
          buyDate: _buyDate,
          buyPrice: 0,
          qty: 0,
        );
    t
      ..market = _market
      ..name = _name.text.trim()
      ..currency = _currency
      ..buyDate = _buyDate
      ..buyPrice = parseNum(_buyPrice.text)!
      ..qty = parseNum(_qty.text)!
      ..fxRate = fx
      ..fee = parseNum(_fee.text) ?? 0
      ..buyReason = _reason.text.trim();
    if (_isClosed) {
      final sp = parseNum(_sellPrice.text);
      if (sp != null && sp > 0) {
        t.sellPrice = sp;
        t.sellDate = _sellDate ?? t.sellDate;
        t.status = (t.pnl ?? 0) >= 0 ? TradeStatus.profit : TradeStatus.loss;
      }
    }
    await store.update(t);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final isUsd = _currency == 'USD';
    final unit = isUsd ? '달러' : '원';
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? '기록 수정' : '매수 기록')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('시장', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            SegmentedButton<Market>(
              segments: [
                for (final m in Market.values)
                  ButtonSegment(value: m, label: Text(m.label)),
              ],
              selected: {_market},
              onSelectionChanged: (s) {
                setState(() {
                  _market = s.first;
                  _currency = _market.defaultCurrency;
                });
                if (_currency == 'USD' && _fx.text.isEmpty) _loadFx();
              },
            ),
            const SizedBox(height: 16),
            const Text('가격 통화', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'KRW', label: Text('원화(₩)')),
                ButtonSegment(value: 'USD', label: Text('달러(\$)')),
              ],
              selected: {_currency},
              onSelectionChanged: (s) {
                setState(() => _currency = s.first);
                if (_currency == 'USD' && _fx.text.isEmpty) _loadFx();
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(
                  labelText: '종목명', border: OutlineInputBorder()),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? '종목명을 입력하세요' : null,
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event),
              title: const Text('매수일'),
              trailing: Text(fmtDate(_buyDate),
                  style: const TextStyle(fontSize: 16)),
              onTap: () => _pickDate(false),
            ),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _buyPrice,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                        labelText: '매수 단가($unit)',
                        border: const OutlineInputBorder()),
                    validator: _required,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _qty,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                        labelText: '수량', border: OutlineInputBorder()),
                    validator: _required,
                  ),
                ),
              ],
            ),
            if (isUsd) ...[
              const SizedBox(height: 12),
              TextFormField(
                controller: _fx,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: '환율 (1달러 = ?원)',
                  border: const OutlineInputBorder(),
                  suffixIcon: _fxLoading
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2)),
                        )
                      : IconButton(
                          tooltip: '현재 환율 불러오기',
                          icon: const Icon(Icons.sync),
                          onPressed: _loadFx,
                        ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            TextFormField(
              controller: _fee,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                  labelText: '수수료·세금($unit, 선택)',
                  border: const OutlineInputBorder()),
            ),
            if (_isClosed) ...[
              const SizedBox(height: 20),
              const Divider(),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event_available),
                title: const Text('매도일'),
                trailing: Text(_sellDate == null ? '-' : fmtDate(_sellDate!),
                    style: const TextStyle(fontSize: 16)),
                onTap: () => _pickDate(true),
              ),
              TextFormField(
                controller: _sellPrice,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                    labelText: '매도 단가($unit)',
                    border: const OutlineInputBorder()),
                validator: _required,
              ),
            ],
            const SizedBox(height: 12),
            TextFormField(
              controller: _reason,
              maxLines: 3,
              decoration: const InputDecoration(
                  labelText: '매수 이유 (선택)',
                  hintText: '왜 샀는지 간단히 적어두면 복기할 때 좋아요',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _save,
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16)),
              child: const Text('저장', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
